import { Badge } from "./ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { AlertTriangle, Shield, TrendingUp } from "lucide-react";
import { missingItems } from "../data/mockData";

export function ExecutiveSummary() {
  const missingThreats = missingItems.filter(item => item.type === 'threat');
  const missingBarriers = missingItems.filter(item => item.type === 'barrier');

  const criticalCount = missingItems.filter(item => item.severity === 'critical').length;
  const highCount = missingItems.filter(item => item.severity === 'high').length;
  const mediumCount = missingItems.filter(item => item.severity === 'medium').length;

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-gray-900">Executive Summary</h2>
        <p className="text-gray-600 mt-1">
          Overview of missing threats and barriers in the highway driving safety bowtie analysis
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Total Missing Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-semibold text-gray-900">{missingItems.length}</div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <div className="mt-3 flex gap-2 text-sm">
              <span className="text-gray-600">{missingThreats.length} Threats</span>
              <span className="text-gray-400">•</span>
              <span className="text-gray-600">{missingBarriers.length} Barriers</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Severity Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Critical</span>
                <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
                  {criticalCount}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">High</span>
                <Badge variant="outline" className="bg-orange-100 text-orange-800 border-orange-200">
                  {highCount}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Medium</span>
                <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                  {mediumCount}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Average Confidence</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-semibold text-gray-900">
                {Math.round(missingItems.reduce((sum, item) => sum + item.confidence, 0) / missingItems.length)}%
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Shield className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <p className="text-sm text-gray-600 mt-3">High confidence in recommendations</p>
          </CardContent>
        </Card>
      </div>

      {/* Missing Threats */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            <CardTitle>Missing Threats</CardTitle>
          </div>
          <CardDescription>
            Potential hazards not currently identified in the bowtie analysis
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {missingThreats.map(threat => (
              <div 
                key={threat.id}
                className="flex items-start justify-between p-4 bg-gray-50 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="font-medium text-gray-900">{threat.title}</h4>
                    <Badge variant="outline" className={getSeverityColor(threat.severity)}>
                      {threat.severity.toUpperCase()}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{threat.description}</p>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-gray-500">Category: <span className="text-gray-700">{threat.category}</span></span>
                    <span className="text-gray-500">Confidence: <span className="text-gray-700">{threat.confidence}%</span></span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Missing Barriers */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-600" />
            <CardTitle>Missing Barriers</CardTitle>
          </div>
          <CardDescription>
            Control measures not currently implemented in the bowtie analysis
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {missingBarriers.map(barrier => (
              <div 
                key={barrier.id}
                className="flex items-start justify-between p-4 bg-gray-50 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="font-medium text-gray-900">{barrier.title}</h4>
                    <Badge variant="outline" className={getSeverityColor(barrier.severity)}>
                      {barrier.severity.toUpperCase()}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{barrier.description}</p>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-gray-500">Category: <span className="text-gray-700">{barrier.category}</span></span>
                    <span className="text-gray-500">Confidence: <span className="text-gray-700">{barrier.confidence}%</span></span>
                    {barrier.relatedTo && (
                      <span className="text-gray-500">Related to: <span className="text-gray-700">{barrier.relatedTo}</span></span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
