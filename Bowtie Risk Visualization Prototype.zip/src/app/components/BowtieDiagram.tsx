import { useState } from "react";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Plus, Link2, ZoomIn, ZoomOut, Maximize2 } from "lucide-react";
import { missingItems } from "../data/mockData";
import { toast } from "sonner";
import bowtieImage from "figma:asset/764cff848f37dca473cf29c842e9f3fc592b25e7.png";

export function BowtieDiagram() {
  const [zoom, setZoom] = useState(100);
  const [selectedItem, setSelectedItem] = useState<string | null>(null);

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 10, 150));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 10, 50));
  };

  const handleResetZoom = () => {
    setZoom(100);
  };

  const handleAddItem = (itemId: string, title: string) => {
    toast.success(`Adding "${title}" to diagram`, {
      description: "Click on the diagram to place this item"
    });
    setSelectedItem(itemId);
  };

  const handleLinkItem = (itemId: string, title: string) => {
    toast.info(`Linking "${title}"`, {
      description: "Click on an existing element to create a link"
    });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-300';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const missingThreats = missingItems.filter(item => item.type === 'threat');
  const missingBarriers = missingItems.filter(item => item.type === 'barrier');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-gray-900">Interactive Bowtie Diagram</h2>
        <p className="text-gray-600 mt-1">
          Visualize missing threats and barriers in context with your existing analysis
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar - Missing Items */}
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Missing Threats</CardTitle>
              <CardDescription>Click to add to diagram</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {missingThreats.map(threat => (
                <div
                  key={threat.id}
                  className={`p-3 border-2 rounded-lg cursor-pointer transition-all ${
                    selectedItem === threat.id
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300 bg-white'
                  }`}
                  onClick={() => setSelectedItem(threat.id)}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <p className="text-sm font-medium text-gray-900 flex-1">{threat.title}</p>
                    <Badge variant="outline" className={`text-xs ${getSeverityColor(threat.severity)}`}>
                      {threat.severity[0].toUpperCase()}
                    </Badge>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 text-xs flex-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAddItem(threat.id, threat.title);
                      }}
                    >
                      <Plus className="w-3 h-3 mr-1" />
                      Add
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 text-xs flex-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleLinkItem(threat.id, threat.title);
                      }}
                    >
                      <Link2 className="w-3 h-3 mr-1" />
                      Link
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Missing Barriers</CardTitle>
              <CardDescription>Click to add to diagram</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {missingBarriers.map(barrier => (
                <div
                  key={barrier.id}
                  className={`p-3 border-2 rounded-lg cursor-pointer transition-all ${
                    selectedItem === barrier.id
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300 bg-white'
                  }`}
                  onClick={() => setSelectedItem(barrier.id)}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <p className="text-sm font-medium text-gray-900 flex-1">{barrier.title}</p>
                    <Badge variant="outline" className={`text-xs ${getSeverityColor(barrier.severity)}`}>
                      {barrier.severity[0].toUpperCase()}
                    </Badge>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 text-xs flex-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAddItem(barrier.id, barrier.title);
                      }}
                    >
                      <Plus className="w-3 h-3 mr-1" />
                      Add
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 text-xs flex-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleLinkItem(barrier.id, barrier.title);
                      }}
                    >
                      <Link2 className="w-3 h-3 mr-1" />
                      Link
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Main Diagram Area */}
        <div className="lg:col-span-3">
          <Card className="overflow-hidden">
            <CardHeader className="bg-gray-50">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Highway Driving Safety Bowtie</CardTitle>
                  <CardDescription>
                    {selectedItem 
                      ? 'Click on the diagram to place the selected item' 
                      : 'Select an item from the sidebar to add it to the diagram'}
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleZoomOut}
                    disabled={zoom <= 50}
                  >
                    <ZoomOut className="w-4 h-4" />
                  </Button>
                  <span className="text-sm font-medium text-gray-700 w-12 text-center">
                    {zoom}%
                  </span>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleZoomIn}
                    disabled={zoom >= 150}
                  >
                    <ZoomIn className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleResetZoom}
                  >
                    <Maximize2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="relative bg-white overflow-auto" style={{ maxHeight: '800px' }}>
                {/* Bowtie Diagram Image */}
                <div 
                  className="relative inline-block min-w-full"
                  style={{ 
                    transform: `scale(${zoom / 100})`,
                    transformOrigin: 'top left',
                  }}
                >
                  <img
                    src={bowtieImage}
                    alt="Highway Driving Safety Bowtie Diagram"
                    className="w-full h-auto"
                  />

                  {/* Overlay for Missing Items - Placeholders with highlighting */}
                  {missingItems.map(item => (
                    item.position && (
                      <div
                        key={item.id}
                        className={`absolute p-2 rounded-lg border-2 border-dashed cursor-pointer transition-all ${
                          selectedItem === item.id
                            ? 'bg-blue-100 border-blue-500 shadow-lg'
                            : 'bg-yellow-50 border-yellow-400 hover:bg-yellow-100'
                        }`}
                        style={{
                          left: `${item.position.x}%`,
                          top: `${item.position.y}%`,
                          minWidth: '120px',
                        }}
                        onClick={() => {
                          setSelectedItem(item.id);
                          toast.info(`Selected: ${item.title}`);
                        }}
                      >
                        <div className="text-xs font-medium text-gray-900 mb-1">
                          {item.title}
                        </div>
                        <Badge variant="outline" className={`text-xs ${getSeverityColor(item.severity)}`}>
                          MISSING
                        </Badge>
                      </div>
                    )
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Legend */}
          <Card className="mt-4">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Legend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-yellow-50 border-2 border-dashed border-yellow-400 rounded"></div>
                  <span className="text-sm text-gray-600">Missing Item</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-blue-100 border-2 border-dashed border-blue-500 rounded"></div>
                  <span className="text-sm text-gray-600">Selected Item</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300 text-xs">
                    C
                  </Badge>
                  <span className="text-sm text-gray-600">Critical</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-orange-100 text-orange-800 border-orange-300 text-xs">
                    H
                  </Badge>
                  <span className="text-sm text-gray-600">High</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
