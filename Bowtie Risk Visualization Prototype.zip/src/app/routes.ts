import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { ExecutiveSummary } from "./components/ExecutiveSummary";
import { Details } from "./components/Details";
import { BowtieDiagram } from "./components/BowtieDiagram";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: ExecutiveSummary },
      { path: "details", Component: Details },
      { path: "diagram", Component: BowtieDiagram },
    ],
  },
]);
