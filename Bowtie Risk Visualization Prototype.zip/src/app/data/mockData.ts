export interface MissingItem {
  id: string;
  type: 'threat' | 'barrier';
  category: string;
  title: string;
  description: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  confidence: number;
  evidence: string[];
  relatedTo?: string;
  position?: { x: number; y: number };
}

export const missingItems: MissingItem[] = [
  {
    id: 'T001',
    type: 'threat',
    category: 'Environmental',
    title: 'Poor visibility due to weather',
    description: 'Fog, heavy rain, or snow reducing driver visibility below safe levels',
    severity: 'high',
    confidence: 85,
    evidence: [
      'Weather-related incidents account for 23% of highway crashes',
      'NHTSA data shows increased accident rates during adverse weather',
      'Industry best practices recommend this threat coverage'
    ],
    position: { x: 15, y: 25 }
  },
  {
    id: 'T002',
    type: 'threat',
    category: 'Human Factor',
    title: 'Driver fatigue from long hours',
    description: 'Extended driving periods without adequate rest leading to reduced reaction time',
    severity: 'critical',
    confidence: 92,
    evidence: [
      'Studies show driver fatigue contributes to 30% of fatal crashes',
      'Hours of service violations detected in recent audits',
      'Similar organizations have identified this as critical gap'
    ],
    position: { x: 15, y: 45 }
  },
  {
    id: 'T003',
    type: 'threat',
    category: 'Infrastructure',
    title: 'Road surface deterioration',
    description: 'Potholes, cracks, and uneven surfaces affecting vehicle control',
    severity: 'medium',
    confidence: 78,
    evidence: [
      'Maintenance records show road quality issues in key routes',
      'Driver reports indicate increased surface-related incidents'
    ],
    position: { x: 15, y: 65 }
  },
  {
    id: 'B001',
    type: 'barrier',
    category: 'Preventive',
    title: 'Advanced weather monitoring system',
    description: 'Real-time weather tracking with route alerts and recommendations',
    severity: 'high',
    confidence: 88,
    evidence: [
      'Industry standard for fleet management',
      'Proven to reduce weather-related incidents by 40%',
      'Regulatory guidance recommends proactive weather monitoring'
    ],
    relatedTo: 'T001',
    position: { x: 30, y: 25 }
  },
  {
    id: 'B002',
    type: 'barrier',
    category: 'Preventive',
    title: 'Mandatory rest break scheduling',
    description: 'Automated system enforcing rest periods based on driving hours',
    severity: 'critical',
    confidence: 95,
    evidence: [
      'Required by federal regulations for commercial drivers',
      'Studies show 60% reduction in fatigue-related incidents',
      'Electronic logging device data indicates compliance gaps'
    ],
    relatedTo: 'T002',
    position: { x: 30, y: 45 }
  },
  {
    id: 'B003',
    type: 'barrier',
    category: 'Mitigative',
    title: 'Adaptive suspension systems',
    description: 'Technology to compensate for road surface irregularities',
    severity: 'medium',
    confidence: 72,
    evidence: [
      'Emerging technology with proven benefits in test fleets',
      'Cost-benefit analysis shows positive ROI over 3 years'
    ],
    relatedTo: 'T003',
    position: { x: 75, y: 65 }
  },
  {
    id: 'B004',
    type: 'barrier',
    category: 'Mitigative',
    title: 'Enhanced driver training program',
    description: 'Comprehensive training covering adverse conditions and defensive driving',
    severity: 'high',
    confidence: 90,
    evidence: [
      'Best practice from industry leaders',
      'Insurance data shows trained drivers have 35% fewer incidents',
      'Gap analysis identifies training deficiencies'
    ],
    position: { x: 75, y: 35 }
  }
];

export const existingControls = [
  'Regular vehicle maintenance',
  'Speed monitoring system',
  'Lane departure warning',
  'Collision avoidance system',
  'Driver performance reviews',
  'GPS tracking and route optimization'
];
