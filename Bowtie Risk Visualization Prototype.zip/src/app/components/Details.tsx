import { useState } from "react";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Plus, Link2, X, ChevronDown, ChevronRight, AlertCircle } from "lucide-react";
import { missingItems } from "../data/mockData";
import { toast } from "sonner";

export function Details() {
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set());

  const toggleExpand = (id: string) => {
    const newExpanded = new Set(expandedItems);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedItems(newExpanded);
  };

  const handleAdd = (itemId: string, title: string) => {
    toast.success(`Adding "${title}" to bowtie diagram`, {
      description: "This item will be added to the active analysis"
    });
  };

  const handleLink = (itemId: string, title: string) => {
    toast.info(`Linking "${title}" to existing control`, {
      description: "Select the control to link this item to"
    });
  };

  const handleDismiss = (itemId: string, title: string) => {
    toast.error(`Dismissing "${title}"`, {
      description: "This recommendation will be marked as not applicable"
    });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return 'text-green-600';
    if (confidence >= 75) return 'text-blue-600';
    if (confidence >= 60) return 'text-yellow-600';
    return 'text-orange-600';
  };

  const missingThreats = missingItems.filter(item => item.type === 'threat');
  const missingBarriers = missingItems.filter(item => item.type === 'barrier');

  const renderItem = (item: typeof missingItems[0]) => {
    const isExpanded = expandedItems.has(item.id);

    return (
      <Card key={item.id} className="overflow-hidden">
        <CardHeader className="pb-3 bg-gray-50">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <button
                  onClick={() => toggleExpand(item.id)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {isExpanded ? (
                    <ChevronDown className="w-5 h-5" />
                  ) : (
                    <ChevronRight className="w-5 h-5" />
                  )}
                </button>
                <CardTitle className="text-base">{item.title}</CardTitle>
              </div>
              <div className="flex items-center gap-2 ml-8">
                <Badge variant="outline" className={getSeverityColor(item.severity)}>
                  {item.severity.toUpperCase()}
                </Badge>
                <Badge variant="outline" className="bg-gray-100 text-gray-700">
                  {item.category}
                </Badge>
                <div className="flex items-center gap-1 text-sm">
                  <span className="text-gray-500">Confidence:</span>
                  <span className={`font-medium ${getConfidenceColor(item.confidence)}`}>
                    {item.confidence}%
                  </span>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleAdd(item.id, item.title)}
                className="gap-1"
              >
                <Plus className="w-4 h-4" />
                Add
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleLink(item.id, item.title)}
                className="gap-1"
              >
                <Link2 className="w-4 h-4" />
                Link
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleDismiss(item.id, item.title)}
                className="gap-1 text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <X className="w-4 h-4" />
                Dismiss
              </Button>
            </div>
          </div>
        </CardHeader>

        {isExpanded && (
          <CardContent className="pt-4">
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Description</h4>
                <p className="text-sm text-gray-600">{item.description}</p>
              </div>

              {item.relatedTo && (
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-blue-900">Related Item</p>
                      <p className="text-sm text-blue-700">This barrier addresses threat {item.relatedTo}</p>
                    </div>
                  </div>
                </div>
              )}

              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Evidence</h4>
                <ul className="space-y-2">
                  {item.evidence.map((evidence, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm text-gray-600">
                      <span className="text-blue-600 mt-1">•</span>
                      <span>{evidence}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-3 border-t border-gray-200">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Item ID: {item.id}</span>
                  <span className="text-gray-500">
                    Type: <span className="font-medium text-gray-700">{item.type === 'threat' ? 'Threat' : 'Barrier'}</span>
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        )}
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-gray-900">Missing Items Details</h2>
        <p className="text-gray-600 mt-1">
          Detailed analysis of missing threats and barriers with evidence and recommended actions
        </p>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList>
          <TabsTrigger value="all">
            All Items ({missingItems.length})
          </TabsTrigger>
          <TabsTrigger value="threats">
            Threats ({missingThreats.length})
          </TabsTrigger>
          <TabsTrigger value="barriers">
            Barriers ({missingBarriers.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4 mt-6">
          <div className="space-y-4">
            {missingItems.map(renderItem)}
          </div>
        </TabsContent>

        <TabsContent value="threats" className="space-y-4 mt-6">
          <div className="space-y-4">
            {missingThreats.map(renderItem)}
          </div>
        </TabsContent>

        <TabsContent value="barriers" className="space-y-4 mt-6">
          <div className="space-y-4">
            {missingBarriers.map(renderItem)}
          </div>
        </TabsContent>
      </Tabs>

      {/* Action Legend */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-base">Available Actions</CardTitle>
          <CardDescription className="text-blue-700">
            Use these actions to manage missing items in your bowtie analysis
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                <Plus className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">Add</p>
                <p className="text-sm text-gray-600">Add this item to your bowtie diagram as a new threat or barrier</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                <Link2 className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">Link</p>
                <p className="text-sm text-gray-600">Link this item to an existing control or threat in your analysis</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                <X className="w-4 h-4 text-red-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">Dismiss</p>
                <p className="text-sm text-gray-600">Mark this item as not applicable to your current analysis</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
